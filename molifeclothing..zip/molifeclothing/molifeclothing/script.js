// Initialize EmailJS (replace with your own user ID from EmailJS dashboard)
emailjs.init("eLfyxf7CJO8z4tbbv");

document.getElementById("enquiryForm").addEventListener("submit", function(event) {
  event.preventDefault();

  let name = document.getElementById("name").value.trim();
   let fname = document.getElementById("fname").value.trim();
  let email = document.getElementById("email").value.trim();
  let message = document.getElementById("message").value.trim();
  let status = document.getElementById("status");

  // Simple validation
  if (name === "" ||fname === "" || email === "" || message === "") {
    status.textContent = "All fields are required!";
    status.style.color = "red";
    return;
  }

  // Email format check
  let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
  if (!email.match(emailPattern)) {
    status.textContent = "Please enter a valid email!";
    status.style.color = "red";
    return;
  }

  // Send email via EmailJS
  emailjs.send("service_ouzu4ob", "template_onshney", {
    from_name: name,
    from_fname: fname,
    from_email: email,
    message: message
  }).then(function(response) {
    status.textContent = "Message sent successfully!";
    status.style.color = "green";
    document.getElementById("enquiryForm").reset();
  }, function(error) {
    status.textContent = "Failed to send message. Try again.";
    status.style.color = "red";
  });
});

